package com.exemplo.contador

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val relogio = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            atualizar()
            relogio.postDelayed(this, 1000)
        }
    }

    private lateinit var tvStatus: TextView
    private lateinit var tvPermissoes: TextView
    private lateinit var tvTotal: TextView
    private lateinit var tvMetaInfo: TextView
    private lateinit var barra: ProgressBar
    private lateinit var tvTaxa: TextView
    private lateinit var tvTempo: TextView
    private lateinit var llJobs: LinearLayout
    private lateinit var spinner: Spinner
    private lateinit var etTermos: EditText
    private lateinit var tvRegiao: TextView
    private lateinit var etMeta: EditText
    private lateinit var tvJogo: TextView
    private lateinit var tvAcessoUso: TextView
    private lateinit var llSessoes: LinearLayout
    private val bolinhas = mutableListOf<View>()

    // ---------- helpers de tela ----------

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun campo(numerico: Boolean, dica: String = ""): EditText {
        val et = EditText(this)
        et.setTextColor(Cores.TEXTO)
        et.setHintTextColor(Cores.TEXTO2)
        et.hint = dica
        et.textSize = 15f
        et.setSingleLine(true)
        if (numerico) et.inputType = InputType.TYPE_CLASS_NUMBER
        et.background = fundo(this, Cores.CAMPO, 10, Cores.BORDA)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        return et
    }

    private fun duas(a: View, b: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        val lpA = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lpA.marginEnd = dp(8)
        l.addView(a, lpA)
        l.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return l
    }

    private fun linhaValor(nome: String, valor: String): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.setPadding(0, dp(3), 0, dp(3))
        l.addView(texto(this, nome, 13f, Cores.TEXTO2), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = texto(this, valor, 13f, Cores.TEXTO)
        v.gravity = Gravity.END
        l.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return l
    }

    private fun interruptor(rotulo: String, ligado: Boolean, aoMudar: (Boolean) -> Unit): Switch {
        val sw = Switch(this)
        sw.text = rotulo
        sw.setTextColor(Cores.TEXTO)
        sw.isChecked = ligado
        sw.setOnCheckedChangeListener { _, marcado -> aoMudar(marcado) }
        return sw
    }

    private fun deslizante(max: Int, valor: Int, aoMudar: (Int) -> Unit): SeekBar {
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = valor
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, doUsuario: Boolean) {
                aoMudar(p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        return sb
    }

    private fun confirmar(titulo: String, mensagem: String, acao: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(mensagem)
            .setPositiveButton("Confirmar") { _, _ -> acao() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun marcarCores() {
        val atual = Cfg.cor(this)
        for (i in bolinhas.indices) {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(Cfg.coresBalao[i])
            if (i == atual) g.setStroke(dp(3), Color.WHITE) else g.setStroke(dp(1), Cores.BORDA)
            bolinhas[i].background = g
        }
    }

    // ---------- construção da tela ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Cores.FUNDO))

        val coluna = LinearLayout(this)
        coluna.orientation = LinearLayout.VERTICAL
        coluna.setPadding(dp(16), dp(12), dp(16), dp(24))

        val rolagem = ScrollView(this)
        rolagem.setBackgroundColor(Cores.FUNDO)
        rolagem.addView(coluna)
        rolagem.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
        setContentView(rolagem)

        // topo
        coluna.addView(texto(this, "Contador de Salário", 26f, Cores.TEXTO, true))
        coluna.adicionar(texto(this, "Soma automática dos pagamentos do jogo", 14f, Cores.TEXTO2), 2)
        tvStatus = texto(this, "", 14f, Cores.TEXTO2, true)
        coluna.adicionar(tvStatus, 14)
        tvPermissoes = texto(this, "", 12f, Cores.TEXTO2)
        coluna.adicionar(tvPermissoes, 2)
        coluna.adicionar(
            duas(
                botao(this, "Iniciar contador", primario = true) { iniciar() },
                botao(this, "Parar") { stopService(Intent(this, CounterService::class.java)) }
            ), 10
        )

        // resumo
        val resumo = cartao(this, "Resumo")
        tvTotal = texto(this, "R\$ 0", 34f, Cores.VERDE, true)
        resumo.adicionar(tvTotal, 6)
        tvMetaInfo = texto(this, "", 13f, Cores.TEXTO2)
        resumo.adicionar(tvMetaInfo, 2)
        barra = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        barra.max = 100
        barra.progressTintList = ColorStateList.valueOf(Cores.VERDE)
        barra.progressBackgroundTintList = ColorStateList.valueOf(Cores.BORDA)
        resumo.adicionar(barra, 10, LinearLayout.LayoutParams.MATCH_PARENT, dp(10))
        tvTaxa = texto(this, "", 13f, Cores.TEXTO)
        resumo.adicionar(tvTaxa, 12)
        tvTempo = texto(this, "", 13f, Cores.TEXTO)
        resumo.adicionar(tvTempo, 2)
        llJobs = LinearLayout(this)
        llJobs.orientation = LinearLayout.VERTICAL
        resumo.adicionar(llJobs, 12)
        coluna.adicionar(resumo, 16)

        // trabalho
        val cJob = cartao(this, "Trabalho")
        spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Jobs.nomes)
        cJob.adicionar(spinner, 8)
        cJob.adicionar(texto(this, "Texto que aparece antes do valor (separe por vírgula)", 12f, Cores.TEXTO2), 12)
        etTermos = campo(false)
        cJob.adicionar(etTermos, 4)
        tvRegiao = texto(this, "", 13f, Cores.TEXTO)
        cJob.adicionar(tvRegiao, 12)
        cJob.adicionar(
            texto(this, "Para ajustar a região: abra o jogo, toque no balão e escolha Calibrar.", 12f, Cores.TEXTO2), 4
        )
        cJob.adicionar(
            duas(
                botao(this, "Salvar texto") {
                    Jobs.salvarTermos(this, Cfg.job(this), etTermos.text.toString())
                    etTermos.setText(Jobs.termos(this, Cfg.job(this)))
                    toast("Texto salvo")
                },
                botao(this, "Restaurar padrão") {
                    confirmar("Restaurar padrão?", "A região e o texto deste trabalho voltam ao original.") {
                        Jobs.restaurar(this, Cfg.job(this))
                        etTermos.setText(Jobs.termos(this, Cfg.job(this)))
                        atualizar()
                    }
                }
            ), 12
        )
        coluna.adicionar(cJob, 16)
        spinner.setSelection(Cfg.job(this))
        etTermos.setText(Jobs.termos(this, Cfg.job(this)))
        // meta
        val cMeta = cartao(this, "Meta")
        etMeta = campo(true, "0 = sem meta")
        if (Cfg.meta(this) > 0) etMeta.setText(Cfg.meta(this).toString())
        cMeta.adicionar(etMeta, 8)
        cMeta.adicionar(
            botao(this, "Salvar meta") {
                Cfg.setMeta(this, etMeta.text.toString().toLongOrNull() ?: 0L)
                toast("Meta salva")
                atualizar()
            }, 10
        )
        cMeta.adicionar(
            texto(this, "Quando bater a meta, o celular vibra e toca um aviso.", 12f, Cores.TEXTO2), 8
        )
        coluna.adicionar(cMeta, 16)

        // balão
        val cBalao = cartao(this, "Balão no jogo")
        val lblTam = texto(this, "Tamanho do texto: ${Cfg.tamanho(this)}", 13f, Cores.TEXTO)
        cBalao.adicionar(lblTam, 10)
        cBalao.adicionar(deslizante(13, Cfg.tamanho(this) - 11) { p ->
            Cfg.setTamanho(this, p + 11)
            lblTam.text = "Tamanho do texto: ${p + 11}"
        }, 4)
        val lblOp = texto(this, "Fundo do balão: ${Cfg.opacidade(this)}%", 13f, Cores.TEXTO)
        cBalao.adicionar(lblOp, 10)
        cBalao.adicionar(deslizante(100, Cfg.opacidade(this)) { p ->
            Cfg.setOpacidade(this, p)
            lblOp.text = "Fundo do balão: $p%"
        }, 4)
        cBalao.adicionar(texto(this, "Cor do texto", 13f, Cores.TEXTO), 12)
        val linhaCores = LinearLayout(this)
        linhaCores.orientation = LinearLayout.HORIZONTAL
        for (i in Cfg.coresBalao.indices) {
            val bola = View(this)
            bola.setOnClickListener {
                Cfg.setCor(this, i)
                marcarCores()
            }
            bolinhas.add(bola)
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.marginEnd = dp(12)
            linhaCores.addView(bola, lp)
        }
        marcarCores()
        cBalao.adicionar(linhaCores, 6)
        cBalao.adicionar(interruptor("Modo compacto (só o valor)", Cfg.compacto(this)) { Cfg.setCompacto(this, it) }, 14)
        cBalao.adicionar(interruptor("Melhorar leitura (experimental)", Cfg.melhorar(this)) { Cfg.setMelhorar(this, it) }, 8)
        cBalao.adicionar(interruptor("Modo teste (mostra o texto lido)", Cfg.teste(this)) { Cfg.setTeste(this, it) }, 8)
        coluna.adicionar(cBalao, 16)

        // jogo
        val cJogo = cartao(this, "Jogo")
        tvJogo = texto(this, "", 14f, Cores.TEXTO)
        cJogo.adicionar(tvJogo, 8)
        cJogo.adicionar(
            texto(
                this,
                "Com o jogo escolhido e o acesso ao uso de apps ativo, o balão some e a leitura pausa quando você sai do jogo. Isso também poupa bateria.",
                12f, Cores.TEXTO2
            ), 4
        )
        tvAcessoUso = texto(this, "", 13f, Cores.TEXTO)
        cJogo.adicionar(tvAcessoUso, 10)
        cJogo.adicionar(
            duas(
                botao(this, "Escolher jogo") { escolherJogo() },
                botao(this, "Acesso ao uso") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            ), 10
        )
        cJogo.adicionar(botao(this, "Não esconder o balão") {
            Cfg.setJogo(this, "", "")
            atualizar()
        }, 8)
        coluna.adicionar(cJogo, 16)

        // histórico
        val cHist = cartao(this, "Histórico")
        llSessoes = LinearLayout(this)
        llSessoes.orientation = LinearLayout.VERTICAL
        cHist.adicionar(llSessoes, 8)
        cHist.adicionar(
            duas(
                botao(this, "Desfazer última") {
                    val e = Store.desfazer(this)
                    toast(if (e == null) "Nada para desfazer" else "Removido: " + Fmt.rs(e.v.toLong()))
                    atualizar()
                },
                botao(this, "Exportar CSV") {
                    val nome = Store.exportarCsv(this)
                    toast(if (nome == null) "Nada para exportar" else "Salvo em Downloads: $nome")
                }
            ), 12
        )
        cHist.adicionar(
            duas(
                botao(this, "Zerar total", perigo = true) {
                    confirmar("Zerar o total?", "O histórico é mantido, só o total volta a zero.") {
                        Cfg.zerar(this)
                        atualizar()
                    }
                },
                botao(this, "Limpar histórico", perigo = true) {
                    confirmar("Apagar o histórico?", "Todos os pagamentos registrados serão apagados. Isso não pode ser desfeito.") {
                        Store.limpar(this)
                        Cfg.zerar(this)
                        atualizar()
                    }
                }
            ), 8
        )
        coluna.adicionar(cHist, 16)

        val rodape = texto(this, "Versão 3.0 · funciona sem internet", 12f, Cores.TEXTO2)
        rodape.gravity = Gravity.CENTER
        coluna.adicionar(rodape, 20)

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Cfg.setJob(this@MainActivity, pos)
                etTermos.setText(Jobs.termos(this@MainActivity, pos))
                atualizar()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        coluna.isFocusable = true
        coluna.isFocusableInTouchMode = true
        coluna.requestFocus()

        if (!Perm.notificacoes(this)) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (!Cfg.jaViuBoasVindas(this)) boasVindas()
        atualizar()
    }

    override fun onResume() {
        super.onResume()
        relogio.removeCallbacks(ticker)
        relogio.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        relogio.removeCallbacks(ticker)
    }

    // ---------- atualização dos dados ----------

    private fun marca(ok: Boolean): String = if (ok) "✓" else "✗"

    private fun atualizar() {
        val lista = Store.ler(this)
        val zero = Cfg.zeroEm(this)
        val total = Stats.total(lista, zero)
        val meta = Cfg.meta(this)
        val rodando = CounterService.rodando

        tvStatus.text = if (rodando) "● Contador ativo" else "○ Contador parado"
        tvStatus.setTextColor(if (rodando) Cores.VERDE else Cores.TEXTO2)
        tvPermissoes.text = "Sobreposição " + marca(Perm.sobreposicao(this)) +
            "   Notificações " + marca(Perm.notificacoes(this))

        tvTotal.text = Fmt.rs(total)
        if (meta > 0) {
            tvMetaInfo.text = "Meta " + Fmt.rs(meta) + " · " + Fmt.pct(total, meta) + "% · faltam " +
                Fmt.rs(Math.max(0L, meta - total))
            barra.progress = Fmt.pct(total, meta)
            barra.visibility = View.VISIBLE
        } else {
            tvMetaInfo.text = "Defina uma meta no cartão Meta"
            barra.visibility = View.GONE
        }

        if (rodando) {
            val sessao = CounterService.sessaoInicio
            val taxa = Stats.taxaHora(
                Stats.totalSessao(lista, zero, sessao), Math.max(sessao, zero), System.currentTimeMillis()
            )
            tvTaxa.text = if (taxa == null) "Ganho por hora: calculando (precisa de 5 min)"
            else "Ganho por hora: " + Fmt.rs(Math.round(taxa)) + "/h"
            val horas = if (meta > 0) Stats.horasParaMeta(meta - total, taxa) else null
            tvTempo.text = if (horas == null) "" else "Tempo estimado para a meta: ~" + Fmt.duracao(horas)
        } else {
            tvTaxa.text = "Ganho por hora: inicie o contador para calcular"
            tvTempo.text = ""
        }

        llJobs.removeAllViews()
        val por = Stats.porJob(lista, zero, Jobs.nomes.size)
        for (i in por.indices) {
            if (por[i] > 0) llJobs.addView(linhaValor(Jobs.nomes[i], Fmt.rs(por[i])))
        }

        val r = Jobs.regiao(this, Cfg.job(this))
        tvRegiao.text = "Região de leitura: " + r[0] + "% a " + r[2] + "% da largura, " + r[1] + "% a " + r[3] + "% da altura"

        val jogo = Cfg.jogoNome(this)
        tvJogo.text = "Jogo escolhido: " + (if (jogo.isEmpty()) "nenhum" else jogo)
        tvAcessoUso.text = "Acesso ao uso de apps: " + (if (Perm.usoDeApps(this)) "✓ ativo" else "✗ desligado")

        llSessoes.removeAllViews()
        val sessoes = Stats.sessoes(lista, 5)
        if (sessoes.isEmpty()) {
            llSessoes.addView(texto(this, "Nenhuma sessão ainda.", 13f, Cores.TEXTO2))
        } else {
            val f = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR"))
            for (s in sessoes) {
                val tx = Stats.taxaHora(s.total, s.id, s.fim)
                val extra = if (tx == null) "" else " · " + Fmt.rs(Math.round(tx)) + "/h"
                llSessoes.addView(linhaValor(f.format(Date(s.id)) + " · " + s.qtd + " pag.", Fmt.rs(s.total) + extra))
            }
        }
    }

    // ---------- ações ----------

    private fun boasVindas() {
        AlertDialog.Builder(this)
            .setTitle("Bem-vindo")
            .setMessage(
                "1. Toque em Iniciar contador e permita a sobreposição, as notificações e a captura de tela.\n\n" +
                    "2. Abra o jogo: o balão aparece. Toque nele para trocar de trabalho, calibrar a leitura, desfazer ou zerar.\n\n" +
                    "3. Escolha o jogo no cartão Jogo para o balão sumir quando você sair dele.\n\n" +
                    "O app só lê o texto da região indicada e não usa a internet."
            )
            .setPositiveButton("Entendi") { _, _ -> Cfg.setViuBoasVindas(this) }
            .setCancelable(false)
            .show()
    }

    private fun iniciar() {
        if (!Perm.sobreposicao(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Permita a sobreposição e toque em Iniciar de novo")
            return
        }
        if (CounterService.rodando) {
            toast("O contador já está ativo")
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CounterService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            toast("Iniciado! Abra o jogo.")
        }
    }

    private fun escolherJogo() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        if (apps.isEmpty()) {
            toast("Nenhum app encontrado")
            return
        }
        val nomes = apps.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Qual é o jogo?")
            .setItems(nomes) { _, i ->
                Cfg.setJogo(this, apps[i].second, apps[i].first)
                atualizar()
            }
            .show()
    }
}
