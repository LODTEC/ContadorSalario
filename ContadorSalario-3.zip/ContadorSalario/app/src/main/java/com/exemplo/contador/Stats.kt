package com.exemplo.contador

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Um pagamento lido: t = quando, j = trabalho, v = valor, s = sessão (hora em que o contador iniciou). */
data class Entrada(val t: Long, val j: Int, val v: Int, val s: Long)

data class Sessao(val id: Long, val fim: Long, val total: Long, val qtd: Int)

object Stats {
    fun serializar(e: List<Entrada>): String = e.joinToString("\n") { "${it.t},${it.j},${it.v},${it.s}" }

    fun ler(txt: String): MutableList<Entrada> {
        val out = mutableListOf<Entrada>()
        for (linha in txt.lineSequence()) {
            val p = linha.trim().split(",")
            if (p.size != 4) continue
            val t = p[0].toLongOrNull() ?: continue
            val j = p[1].toIntOrNull() ?: continue
            val v = p[2].toIntOrNull() ?: continue
            val s = p[3].toLongOrNull() ?: continue
            out.add(Entrada(t, j, v, s))
        }
        return out
    }

    fun total(e: List<Entrada>, zeroAt: Long): Long {
        var soma = 0L
        for (x in e) if (x.t >= zeroAt) soma += x.v
        return soma
    }

    fun totalSessao(e: List<Entrada>, zeroAt: Long, sessao: Long): Long {
        var soma = 0L
        for (x in e) if (x.t >= zeroAt && x.s == sessao) soma += x.v
        return soma
    }

    fun porJob(e: List<Entrada>, zeroAt: Long, n: Int): LongArray {
        val r = LongArray(n)
        for (x in e) if (x.t >= zeroAt && x.j in 0 until n) r[x.j] += x.v.toLong()
        return r
    }

    /** Média dos últimos pagamentos do trabalho e quantos foram considerados. */
    fun media(e: List<Entrada>, zeroAt: Long, job: Int, ultimos: Int = 20): Pair<Double?, Int> {
        val valores = ArrayList<Int>()
        for (i in e.indices.reversed()) {
            val x = e[i]
            if (x.t < zeroAt || x.j != job) continue
            valores.add(x.v)
            if (valores.size >= ultimos) break
        }
        if (valores.isEmpty()) return Pair(null, 0)
        return Pair(valores.sum().toDouble() / valores.size, valores.size)
    }

    fun sessoes(e: List<Entrada>, max: Int = 5): List<Sessao> {
        val mapa = LinkedHashMap<Long, MutableList<Entrada>>()
        for (x in e) mapa.getOrPut(x.s) { mutableListOf() }.add(x)
        return mapa.entries
            .map { (id, lista) -> Sessao(id, lista.maxOf { it.t }, lista.sumOf { it.v.toLong() }, lista.size) }
            .sortedByDescending { it.id }
            .take(max)
    }

    /** R$ por hora; só calcula depois de 5 minutos para não dar número maluco no começo. */
    fun taxaHora(total: Long, inicio: Long, agora: Long): Double? {
        val ms = agora - inicio
        if (ms < 300_000L) return null
        return total / (ms / 3_600_000.0)
    }

    fun horasParaMeta(restante: Long, taxa: Double?): Double? {
        if (taxa == null || taxa <= 0.0 || restante <= 0L) return null
        return restante / taxa
    }

    fun csv(e: List<Entrada>, nomes: List<String>): String {
        val f = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("pt", "BR"))
        val sb = StringBuilder("﻿Data;Trabalho;Valor;Sessao\n")
        for (x in e) {
            val nome = nomes.getOrElse(x.j) { "?" }
            sb.append(f.format(Date(x.t))).append(';').append(nome).append(';').append(x.v).append(';')
                .append(f.format(Date(x.s))).append('\n')
        }
        return sb.toString()
    }
}
