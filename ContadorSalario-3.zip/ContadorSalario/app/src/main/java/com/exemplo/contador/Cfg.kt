package com.exemplo.contador

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Process
import android.provider.Settings

object Cfg {
    val coresBalao = intArrayOf(
        Color.parseColor("#34D399"), // verde
        Color.parseColor("#FFFFFF"), // branco
        Color.parseColor("#FBBF24"), // amarelo
        Color.parseColor("#22D3EE")  // ciano
    )

    fun p(ctx: Context): SharedPreferences = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun job(ctx: Context): Int = p(ctx).getInt("job", 0).coerceIn(0, Jobs.nomes.size - 1)
    fun setJob(ctx: Context, j: Int) = p(ctx).edit().putInt("job", j).apply()

    fun meta(ctx: Context): Long = p(ctx).getLong("meta", 0L)
    fun setMeta(ctx: Context, v: Long) = p(ctx).edit().putLong("meta", v).apply()

    fun tamanho(ctx: Context): Int = p(ctx).getInt("tamanho", 15).coerceIn(11, 24)
    fun setTamanho(ctx: Context, v: Int) = p(ctx).edit().putInt("tamanho", v).apply()

    fun opacidade(ctx: Context): Int = p(ctx).getInt("opacidade", 60).coerceIn(0, 100)
    fun setOpacidade(ctx: Context, v: Int) = p(ctx).edit().putInt("opacidade", v).apply()

    fun cor(ctx: Context): Int = p(ctx).getInt("cor", 0).coerceIn(0, coresBalao.size - 1)
    fun setCor(ctx: Context, v: Int) = p(ctx).edit().putInt("cor", v).apply()

    fun compacto(ctx: Context): Boolean = p(ctx).getBoolean("compacto", false)
    fun setCompacto(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("compacto", v).apply()

    fun melhorar(ctx: Context): Boolean = p(ctx).getBoolean("melhorar", false)
    fun setMelhorar(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("melhorar", v).apply()

    fun teste(ctx: Context): Boolean = p(ctx).getBoolean("teste", false)
    fun setTeste(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("teste", v).apply()

    fun jogoPkg(ctx: Context): String = p(ctx).getString("jogo_pkg", "") ?: ""
    fun jogoNome(ctx: Context): String = p(ctx).getString("jogo_nome", "") ?: ""
    fun setJogo(ctx: Context, pkg: String, nome: String) =
        p(ctx).edit().putString("jogo_pkg", pkg).putString("jogo_nome", nome).apply()

    fun jaViuBoasVindas(ctx: Context): Boolean = p(ctx).getBoolean("boas_vindas", false)
    fun setViuBoasVindas(ctx: Context) = p(ctx).edit().putBoolean("boas_vindas", true).apply()

    fun zeroEm(ctx: Context): Long = p(ctx).getLong("zero_em", 0L)
    fun zerar(ctx: Context) = p(ctx).edit().putLong("zero_em", System.currentTimeMillis()).apply()
}

object Perm {
    fun sobreposicao(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun notificacoes(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun usoDeApps(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val modo = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return modo == AppOpsManager.MODE_ALLOWED
    }
}
