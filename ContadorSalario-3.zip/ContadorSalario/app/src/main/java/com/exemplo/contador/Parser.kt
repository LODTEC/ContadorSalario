package com.exemplo.contador

/** Lê o valor em reais que aparece depois de um texto (ex.: "= 90" ou "Total ganho: R$ 408"). */
object Parser {
    private const val CLASSE = "[0-9OoIl|S]"

    /** Converte o texto bruto do OCR em número. Corrige confusões comuns (O→0, l→1, S→5). */
    fun valorDe(bruto: String): Int? {
        if (bruto.none { it in '0'..'9' }) return null
        val s = bruto.map {
            when (it) {
                'O', 'o' -> '0'
                'I', 'l', '|' -> '1'
                'S' -> '5'
                else -> it
            }
        }.joinToString("").trim('.', ',')
        val n = when {
            Regex("^\\d{1,3}([.,]\\d{3})+$").matches(s) -> s.replace(".", "").replace(",", "")
            Regex("^\\d+[.,]\\d{1,2}$").matches(s) -> s.substring(0, s.indexOfFirst { it == '.' || it == ',' })
            Regex("^\\d+$").matches(s) -> s
            else -> return null
        }
        val v = n.toLongOrNull() ?: return null
        return if (v in 1..9_999_999L) v.toInt() else null
    }

    /** Procura cada texto da lista (separados por vírgula) e devolve o primeiro valor válido logo depois dele. */
    fun extrair(texto: String, termos: String): Int? {
        val lista = termos.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        for (t in lista) {
            val r = Regex(
                "(?i:" + Regex.escape(t) + ")\\s*:?\\s*(?:R\\s?\\$|RS|R5)?\\s*(" + CLASSE + "[0-9OoIl|S.,]{0,9})"
            )
            for (m in r.findAll(texto)) {
                val v = valorDe(m.groupValues[1])
                if (v != null) return v
            }
        }
        return null
    }
}
