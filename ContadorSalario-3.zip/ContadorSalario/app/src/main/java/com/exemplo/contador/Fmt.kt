package com.exemplo.contador

object Fmt {
    fun milhar(v: Long): String {
        val neg = v < 0
        val s = Math.abs(v).toString()
        val sb = StringBuilder()
        for ((i, c) in s.withIndex()) {
            if (i > 0 && (s.length - i) % 3 == 0) sb.append('.')
            sb.append(c)
        }
        return (if (neg) "-" else "") + sb.toString()
    }

    fun rs(v: Long): String = "R\$ " + milhar(v)

    fun duracao(horas: Double): String {
        val min = Math.round(horas * 60).toInt()
        if (min < 1) return "menos de 1 min"
        val h = min / 60
        val m = min % 60
        return when {
            h == 0 -> "${m}min"
            m == 0 -> "${h}h"
            else -> "${h}h" + m.toString().padStart(2, '0')
        }
    }

    fun pct(parte: Long, total: Long): Int =
        if (total <= 0) 0 else Math.min(100L, parte * 100 / total).toInt()
}
