package com.exemplo.contador

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico de pagamentos. Fica em memória e em um arquivo do app. */
object Store {
    private const val ARQUIVO = "historico.txt"
    private const val LIMITE = 5000
    private var cache: MutableList<Entrada>? = null

    @Synchronized
    fun ler(ctx: Context): List<Entrada> {
        val atual = cache
        if (atual != null) return atual
        val f = File(ctx.filesDir, ARQUIVO)
        val lista = if (f.exists()) Stats.ler(f.readText()) else mutableListOf()
        cache = lista
        return lista
    }

    private fun gravar(ctx: Context, lista: List<Entrada>) {
        File(ctx.filesDir, ARQUIVO).writeText(Stats.serializar(lista))
    }

    @Synchronized
    fun adicionar(ctx: Context, e: Entrada) {
        ler(ctx)
        val lista = cache!!
        lista.add(e)
        while (lista.size > LIMITE) lista.removeAt(0)
        gravar(ctx, lista)
    }

    /** Remove o último pagamento (só se for posterior ao último "zerar"). */
    @Synchronized
    fun desfazer(ctx: Context): Entrada? {
        ler(ctx)
        val lista = cache!!
        if (lista.isEmpty()) return null
        if (lista[lista.size - 1].t < Cfg.zeroEm(ctx)) return null
        val e = lista.removeAt(lista.size - 1)
        gravar(ctx, lista)
        return e
    }

    @Synchronized
    fun limpar(ctx: Context) {
        cache = mutableListOf()
        File(ctx.filesDir, ARQUIVO).delete()
    }

    fun total(ctx: Context): Long = Stats.total(ler(ctx), Cfg.zeroEm(ctx))

    /** Salva um CSV na pasta Downloads. Devolve o nome do arquivo ou null se não houver dados. */
    fun exportarCsv(ctx: Context): String? {
        val lista = ler(ctx)
        if (lista.isEmpty()) return null
        val nome = "contador_salario_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".csv"
        val valores = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, nome)
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores) ?: return null
        val saida = ctx.contentResolver.openOutputStream(uri) ?: return null
        saida.use { it.write(Stats.csv(lista, Jobs.nomes).toByteArray(Charsets.UTF_8)) }
        return nome
    }
}
