package com.exemplo.contador

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast

/**
 * Tela de calibração: mostra uma foto da tela do jogo e o usuário arrasta o dedo
 * para desenhar um retângulo em volta da caixa onde aparece o salário.
 */
class CalibView(
    private val ctx: Context,
    private val foto: Bitmap,
    regiaoInicial: IntArray,
    aoSalvar: (IntArray) -> Unit,
    aoCancelar: () -> Unit
) : FrameLayout(ctx) {

    private val area = Area(ctx)

    private inner class Area(c: Context) : View(c) {
        private val pFoto = Paint(Paint.FILTER_BITMAP_FLAG)
        private val pEscuro = Paint()
        private val pBorda = Paint(Paint.ANTI_ALIAS_FLAG)
        private val origem = Rect(0, 0, foto.width, foto.height)
        private val destino = Rect()
        var l = 0.34f
        var t = 0.84f
        var r = 0.66f
        var b = 0.96f
        private var x0 = 0f
        private var y0 = 0f

        init {
            pEscuro.color = Color.argb(150, 0, 0, 0)
            pBorda.color = Cores.VERDE
            pBorda.style = Paint.Style.STROKE
            pBorda.strokeWidth = c.dp(2).toFloat()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            destino.set(0, 0, width, height)
            canvas.drawBitmap(foto, origem, destino, pFoto)
            val rl = l * w
            val rt = t * h
            val rr = r * w
            val rb = b * h
            canvas.drawRect(0f, 0f, w, rt, pEscuro)
            canvas.drawRect(0f, rb, w, h, pEscuro)
            canvas.drawRect(0f, rt, rl, rb, pEscuro)
            canvas.drawRect(rr, rt, w, rb, pEscuro)
            canvas.drawRect(rl, rt, rr, rb, pBorda)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val fx = (e.x / width).coerceIn(0f, 1f)
            val fy = (e.y / height).coerceIn(0f, 1f)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = fx; y0 = fy
                    l = fx; r = fx; t = fy; b = fy
                }
                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    l = Math.min(x0, fx); r = Math.max(x0, fx)
                    t = Math.min(y0, fy); b = Math.max(y0, fy)
                }
            }
            invalidate()
            return true
        }
    }

    init {
        area.l = regiaoInicial[0] / 100f
        area.t = regiaoInicial[1] / 100f
        area.r = regiaoInicial[2] / 100f
        area.b = regiaoInicial[3] / 100f
        addView(area, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val barra = LinearLayout(ctx)
        barra.orientation = LinearLayout.HORIZONTAL
        barra.gravity = Gravity.CENTER_VERTICAL
        barra.background = fundo(ctx, Color.argb(225, 14, 16, 20), 14)
        barra.setPadding(ctx.dp(14), ctx.dp(10), ctx.dp(10), ctx.dp(10))

        val dica = texto(ctx, "Arraste o dedo sobre a caixa onde aparece o salário", 14f)
        barra.addView(dica, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val cancelar = botao(ctx, "Cancelar") { aoCancelar() }
        val salvar = botao(ctx, "Salvar", primario = true) {
            if (area.r - area.l < 0.02f || area.b - area.t < 0.01f) {
                Toast.makeText(ctx, "Desenhe uma área maior em volta do texto", Toast.LENGTH_SHORT).show()
            } else {
                aoSalvar(
                    intArrayOf(
                        Math.round(area.l * 100), Math.round(area.t * 100),
                        Math.round(area.r * 100), Math.round(area.b * 100)
                    )
                )
            }
        }
        val lpCancelar = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpCancelar.marginStart = ctx.dp(10)
        barra.addView(cancelar, lpCancelar)
        val lpSalvar = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpSalvar.marginStart = ctx.dp(8)
        barra.addView(salvar, lpSalvar)

        val lpBarra = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        )
        lpBarra.topMargin = ctx.dp(20)
        addView(barra, lpBarra)
    }
}
