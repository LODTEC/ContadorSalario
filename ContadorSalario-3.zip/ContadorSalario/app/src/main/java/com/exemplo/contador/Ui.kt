package com.exemplo.contador

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object Cores {
    val FUNDO = Color.parseColor("#0E1014")
    val CARD = Color.parseColor("#171A21")
    val CAMPO = Color.parseColor("#0E1014")
    val BORDA = Color.parseColor("#2A303B")
    val TEXTO = Color.parseColor("#F2F4F8")
    val TEXTO2 = Color.parseColor("#9AA3B2")
    val VERDE = Color.parseColor("#34D399")
    val VERDE_ESCURO = Color.parseColor("#0B3D2E")
    val AMARELO = Color.parseColor("#FBBF24")
    val VERMELHO = Color.parseColor("#F87171")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun fundo(ctx: Context, cor: Int, raioDp: Int, borda: Int? = null): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(cor)
    g.cornerRadius = ctx.dp(raioDp).toFloat()
    if (borda != null) g.setStroke(ctx.dp(1), borda)
    return g
}

fun texto(ctx: Context, t: String, tamanho: Float = 14f, cor: Int = Cores.TEXTO, negrito: Boolean = false): TextView {
    val tv = TextView(ctx)
    tv.text = t
    tv.textSize = tamanho
    tv.setTextColor(cor)
    if (negrito) tv.setTypeface(tv.typeface, Typeface.BOLD)
    return tv
}

fun cartao(ctx: Context, titulo: String): LinearLayout {
    val c = LinearLayout(ctx)
    c.orientation = LinearLayout.VERTICAL
    c.background = fundo(ctx, Cores.CARD, 16, Cores.BORDA)
    c.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(16))
    c.addView(texto(ctx, titulo.uppercase(), 12f, Cores.TEXTO2, true))
    return c
}

fun botao(ctx: Context, rotulo: String, primario: Boolean = false, perigo: Boolean = false, acao: () -> Unit): TextView {
    val tv = TextView(ctx)
    tv.text = rotulo
    tv.textSize = 14f
    tv.gravity = Gravity.CENTER
    tv.isClickable = true
    tv.setPadding(ctx.dp(14), ctx.dp(11), ctx.dp(14), ctx.dp(11))
    when {
        primario -> {
            tv.setTextColor(Cores.VERDE_ESCURO)
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.background = fundo(ctx, Cores.VERDE, 12)
        }
        perigo -> {
            tv.setTextColor(Cores.VERMELHO)
            tv.background = fundo(ctx, Cores.CARD, 12, Cores.VERMELHO)
        }
        else -> {
            tv.setTextColor(Cores.TEXTO)
            tv.background = fundo(ctx, Cores.CARD, 12, Cores.BORDA)
        }
    }
    tv.setOnClickListener { acao() }
    return tv
}

/** Adiciona uma view com margem no topo. */
fun LinearLayout.adicionar(v: View, topoDp: Int = 8, largura: Int = LinearLayout.LayoutParams.MATCH_PARENT, altura: Int = LinearLayout.LayoutParams.WRAP_CONTENT) {
    val lp = LinearLayout.LayoutParams(largura, altura)
    lp.topMargin = context.dp(topoDp)
    addView(v, lp)
}
