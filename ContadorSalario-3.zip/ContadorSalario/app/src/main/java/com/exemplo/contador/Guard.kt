package com.exemplo.contador

/**
 * Decide quando uma leitura vira um pagamento de verdade:
 * - o mesmo valor precisa aparecer em leituras seguidas (confirmação);
 * - valores muito fora do normal do trabalho exigem mais confirmações;
 * - o valor só conta de novo depois que a caixinha some da tela.
 */
class Guard {
    private var ultimo = 0
    private var candidato = 0
    private var cont = 0
    private var faltas = 0

    fun reset() {
        ultimo = 0; candidato = 0; cont = 0; faltas = 0
    }

    fun alimentar(valor: Int?, media: Double?, amostras: Int): Int? {
        if (valor == null || valor <= 0) {
            faltas++
            if (faltas >= 2) {
                ultimo = 0; candidato = 0; cont = 0
            }
            return null
        }
        faltas = 0
        if (valor == candidato) cont++ else {
            candidato = valor; cont = 1
        }
        val suspeito = media != null && amostras >= 3 && (valor > media * 4 || valor < media / 10)
        val exigidas = if (suspeito) 4 else 2
        if (cont >= exigidas && valor != ultimo) {
            ultimo = valor
            return valor
        }
        return null
    }
}
