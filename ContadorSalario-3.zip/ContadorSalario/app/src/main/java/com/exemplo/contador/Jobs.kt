package com.exemplo.contador

import android.content.Context

object Jobs {
    val nomes = listOf("Caminhoneiro", "Entregador", "Fazenda", "Personalizado")

    private val termosPadrao = listOf("=", "=", "Total ganho:, ganho", "=")
    val regiaoPadrao = intArrayOf(34, 84, 66, 96)
    private val lados = listOf("l", "t", "r", "b")

    /** Região de leitura em % da tela: esquerda, topo, direita, base. */
    fun regiao(ctx: Context, j: Int): IntArray {
        val p = Cfg.p(ctx)
        return IntArray(4) { p.getInt("r${j}_${lados[it]}", regiaoPadrao[it]) }
    }

    fun salvarRegiao(ctx: Context, j: Int, r: IntArray) {
        val e = Cfg.p(ctx).edit()
        for (i in 0..3) e.putInt("r${j}_${lados[i]}", r[i].coerceIn(0, 100))
        e.apply()
    }

    fun termos(ctx: Context, j: Int): String =
        Cfg.p(ctx).getString("termos_$j", termosPadrao[j]) ?: termosPadrao[j]

    fun salvarTermos(ctx: Context, j: Int, t: String) {
        val limpo = if (t.isBlank()) termosPadrao[j] else t.trim()
        Cfg.p(ctx).edit().putString("termos_$j", limpo).apply()
    }

    fun restaurar(ctx: Context, j: Int) {
        val e = Cfg.p(ctx).edit()
        for (i in 0..3) e.remove("r${j}_${lados[i]}")
        e.remove("termos_$j")
        e.apply()
    }
}
