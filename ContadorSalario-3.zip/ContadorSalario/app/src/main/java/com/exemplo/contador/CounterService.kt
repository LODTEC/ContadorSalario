package com.exemplo.contador

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioManager
import android.media.ImageReader
import android.media.ToneGenerator
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.VibratorManager
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CounterService : Service() {

    companion object {
        @Volatile
        var rodando = false

        @Volatile
        var sessaoInicio = 0L
        const val ACAO_PARAR = "app.contadorsalario.PARAR"
        private const val CANAL = "contador"
    }

    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val guard = Guard()

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var curW = 0
    private var curH = 0
    private var dpi = 320

    private lateinit var wm: WindowManager
    private lateinit var raiz: LinearLayout
    private lateinit var balao: TextView
    private lateinit var painel: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private var calibView: CalibView? = null
    private var fotoCalibracao: Bitmap? = null

    private var sessao = 0L
    private var ocupado = false
    private var calibrando = false
    private var emJogo = true
    private var fgPkg = ""
    private var ultimaConsulta = 0L
    private var ultimoTexto = ""
    private var confirmandoZerar = false
    private var estiloAplicado = -1

    private val tick = object : Runnable {
        override fun run() {
            if (!rodando) return
            atualizarPrimeiroPlano()
            if (emJogo && !calibrando) capturar()
            atualizarTexto()
            handler.postDelayed(this, 700)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACAO_PARAR) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent == null || rodando) return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Contador de salário", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(1, criarNotificacao(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra("data", Intent::class.java)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, handler)

        sessao = System.currentTimeMillis()
        sessaoInicio = sessao
        guard.reset()
        criarOverlay()
        rodando = true
        handler.post(tick)
        return START_NOT_STICKY
    }

    // ---------- notificação ----------

    private fun criarNotificacao(): Notification {
        val parar = PendingIntent.getService(
            this, 1, Intent(this, CounterService::class.java).setAction(ACAO_PARAR), PendingIntent.FLAG_IMMUTABLE
        )
        val abrir = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val total = Store.total(this)
        val meta = Cfg.meta(this)
        val texto = if (meta > 0) "${Fmt.rs(total)} de ${Fmt.rs(meta)} (${Fmt.pct(total, meta)}%)" else Fmt.rs(total)
        val acao = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Parar", parar
        ).build()
        return Notification.Builder(this, CANAL)
            .setContentTitle("Contador ativo · " + Jobs.nomes[Cfg.job(this)])
            .setContentText(texto)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(abrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(acao)
            .build()
    }

    private fun atualizarNotificacao() {
        getSystemService(NotificationManager::class.java).notify(1, criarNotificacao())
    }

    // ---------- balão flutuante ----------

    private fun criarOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL

        balao = TextView(this)
        balao.setPadding(dp(10), dp(6), dp(10), dp(6))
        raiz.addView(balao)

        painel = LinearLayout(this)
        painel.orientation = LinearLayout.VERTICAL
        painel.background = fundo(this, Color.argb(240, 14, 16, 20), 12)
        painel.setPadding(dp(8), dp(8), dp(8), dp(8))
        painel.visibility = View.GONE
        montarPainel()
        val lpPainel = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpPainel.topMargin = dp(6)
        raiz.addView(painel, lpPainel)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = Cfg.p(this).getInt("pos_x", dp(16))
        params.y = Cfg.p(this).getInt("pos_y", dp(70))

        var sx = 0f
        var sy = 0f
        var px = 0
        var py = 0
        var moveu = false
        balao.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY
                    px = params.x; py = params.y
                    moveu = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moveu = true
                    if (moveu) {
                        params.x = px + dx
                        params.y = py + dy
                        wm.updateViewLayout(raiz, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moveu) {
                        Cfg.p(this).edit().putInt("pos_x", params.x).putInt("pos_y", params.y).apply()
                    } else {
                        painel.visibility = if (painel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    }
                }
            }
            true
        }
        wm.addView(raiz, params)
        atualizarTexto()
    }

    private fun mini(rotulo: String, perigo: Boolean = false, acao: (TextView) -> Unit): TextView {
        val tv = botao(this, rotulo, perigo = perigo) {}
        tv.textSize = 13f
        tv.setPadding(dp(10), dp(8), dp(10), dp(8))
        tv.setOnClickListener { acao(tv) }
        return tv
    }

    private fun linha(a: View, b: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        val lpA = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lpA.marginEnd = dp(6)
        l.addView(a, lpA)
        l.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return l
    }

    private fun montarPainel() {
        val trocar = mini("Trocar trabalho") { trocarTrabalho() }
        val calibrar = mini("Calibrar") { iniciarCalibracao() }
        val desfazer = mini("Desfazer") {
            val e = Store.desfazer(this)
            if (e == null) {
                aviso("Nada para desfazer")
            } else {
                aviso("Removido: " + Fmt.rs(e.v.toLong()))
                atualizarTexto(); atualizarNotificacao()
            }
        }
        val zerar = mini("Zerar", perigo = true) { zerarComConfirmacao(it) }
        val parar = mini("Parar contador") { stopSelf() }
        val fechar = mini("Fechar") { painel.visibility = View.GONE }

        painel.addView(linha(trocar, calibrar))
        painel.addView(linha(desfazer, zerar), LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
        painel.addView(linha(parar, fechar), LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })
    }

    private fun aviso(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun trocarTrabalho() {
        val novo = (Cfg.job(this) + 1) % Jobs.nomes.size
        Cfg.setJob(this, novo)
        guard.reset()
        ultimoTexto = ""
        atualizarTexto()
        atualizarNotificacao()
    }

    private fun zerarComConfirmacao(btn: TextView) {
        if (!confirmandoZerar) {
            confirmandoZerar = true
            btn.text = "Confirmar?"
            handler.postDelayed({
                confirmandoZerar = false
                btn.text = "Zerar"
            }, 3000)
        } else {
            confirmandoZerar = false
            btn.text = "Zerar"
            Cfg.zerar(this)
            atualizarTexto()
            atualizarNotificacao()
            aviso("Total zerado")
        }
    }

    private fun aplicarEstiloSeMudou() {
        val chave = Cfg.tamanho(this) * 10000 + Cfg.opacidade(this) * 10 + Cfg.cor(this)
        if (chave == estiloAplicado) return
        estiloAplicado = chave
        balao.textSize = Cfg.tamanho(this).toFloat()
        val alfa = Cfg.opacidade(this) * 255 / 100
        balao.background = fundo(this, Color.argb(alfa, 0, 0, 0), 10)
    }

    private fun atualizarTexto() {
        if (!::balao.isInitialized) return
        aplicarEstiloSeMudou()
        val lista = Store.ler(this)
        val zero = Cfg.zeroEm(this)
        val total = Stats.total(lista, zero)
        val meta = Cfg.meta(this)
        val job = Cfg.job(this)
        val agora = System.currentTimeMillis()
        val taxa = Stats.taxaHora(Stats.totalSessao(lista, zero, sessao), Math.max(sessao, zero), agora)
        val bateu = meta > 0 && total >= meta

        val sb = StringBuilder()
        if (Cfg.compacto(this)) {
            sb.append(Fmt.rs(total))
            if (meta > 0) sb.append(if (bateu) " ✔" else " · " + Fmt.pct(total, meta) + "%")
        } else {
            sb.append(Jobs.nomes[job])
            if (bateu) sb.append("  ·  META BATIDA!")
            sb.append('\n').append(Fmt.rs(total))
            if (meta > 0) sb.append(" / ").append(Fmt.rs(meta))
            if (meta > 0 && !bateu) {
                sb.append('\n').append(Fmt.pct(total, meta)).append("% · faltam ").append(Fmt.rs(meta - total))
            }
            if (taxa != null) {
                sb.append('\n').append(Fmt.rs(Math.round(taxa))).append("/h")
                val horas = Stats.horasParaMeta(meta - total, taxa)
                if (meta > 0 && horas != null) sb.append(" · ~").append(Fmt.duracao(horas))
            }
        }
        if (Cfg.teste(this)) {
            sb.append("\nlido: ").append(ultimoTexto.replace('\n', ' ').take(60))
        }
        val novo = sb.toString()
        if (balao.text.toString() != novo) balao.text = novo
        balao.setTextColor(if (bateu) Cores.AMARELO else Cfg.coresBalao[Cfg.cor(this)])
    }

    private fun avisarMeta() {
        try {
            val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 120, 200, 120, 400), -1))
        } catch (_: Exception) {
        }
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 500)
            handler.postDelayed({ tg.release() }, 900)
        } catch (_: Exception) {
        }
    }

    // ---------- esconder fora do jogo ----------

    private fun atualizarPrimeiroPlano() {
        val pkg = Cfg.jogoPkg(this)
        val dentro: Boolean
        if (pkg.isEmpty() || !Perm.usoDeApps(this)) {
            dentro = true
        } else {
            val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val agora = System.currentTimeMillis()
            val de = if (ultimaConsulta == 0L) agora - 3_600_000L else ultimaConsulta
            val eventos = usm.queryEvents(de, agora)
            val e = UsageEvents.Event()
            while (eventos.hasNextEvent()) {
                eventos.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) fgPkg = e.packageName
            }
            ultimaConsulta = agora
            dentro = fgPkg.isEmpty() || fgPkg == pkg || fgPkg == packageName
        }
        emJogo = dentro
        if (!calibrando) {
            val v = if (dentro) View.VISIBLE else View.GONE
            if (raiz.visibility != v) raiz.visibility = v
        }
    }

    // ---------- captura e leitura da tela ----------

    private fun garantirDisplay() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        if (dm.widthPixels == curW && dm.heightPixels == curH && vDisplay != null) return
        curW = dm.widthPixels
        curH = dm.heightPixels
        dpi = dm.densityDpi
        val novoReader = ImageReader.newInstance(curW, curH, PixelFormat.RGBA_8888, 2)
        if (vDisplay == null) {
            vDisplay = projection?.createVirtualDisplay(
                "captura", curW, curH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, novoReader.surface, null, null
            )
        } else {
            vDisplay?.resize(curW, curH, dpi)
            vDisplay?.surface = novoReader.surface
        }
        reader?.close()
        reader = novoReader
    }

    /** Pega o quadro mais recente da tela, já no tamanho certo. */
    private fun quadroAtual(): Bitmap? {
        garantirDisplay()
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val plano = img.planes[0]
            val largLinha = plano.rowStride / plano.pixelStride
            val cheio = Bitmap.createBitmap(largLinha, img.height, Bitmap.Config.ARGB_8888)
            cheio.copyPixelsFromBuffer(plano.buffer)
            if (largLinha == img.width) return cheio
            val corte = Bitmap.createBitmap(cheio, 0, 0, img.width, img.height)
            cheio.recycle()
            return corte
        } finally {
            img.close()
        }
    }

    private fun melhorar(origem: Bitmap): Bitmap {
        val saida = Bitmap.createBitmap(origem.width, origem.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        val c = 1.6f
        val t = (-0.5f * c + 0.5f) * 255f
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    c, 0f, 0f, 0f, t,
                    0f, c, 0f, 0f, t,
                    0f, 0f, c, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        val p = Paint()
        p.colorFilter = ColorMatrixColorFilter(cm)
        Canvas(saida).drawBitmap(origem, 0f, 0f, p)
        return saida
    }

    private fun capturar() {
        if (ocupado) return
        val cheio = quadroAtual() ?: return
        val job = Cfg.job(this)
        val reg = Jobs.regiao(this, job)
        val termos = Jobs.termos(this, job)

        val x = Math.max(0, Math.min(cheio.width - 2, (cheio.width * reg[0] / 100f).toInt()))
        val y = Math.max(0, Math.min(cheio.height - 2, (cheio.height * reg[1] / 100f).toInt()))
        val w = Math.max(2, Math.min(cheio.width - x, (cheio.width * (reg[2] - reg[0]) / 100f).toInt()))
        val h = Math.max(2, Math.min(cheio.height - y, (cheio.height * (reg[3] - reg[1]) / 100f).toInt()))

        val recorte = Bitmap.createBitmap(cheio, x, y, w, h)
        cheio.recycle()
        val ampliado = Bitmap.createScaledBitmap(recorte, w * 2, h * 2, true)
        recorte.recycle()
        val imagem = if (Cfg.melhorar(this)) {
            val m = melhorar(ampliado)
            ampliado.recycle()
            m
        } else {
            ampliado
        }

        ocupado = true
        recognizer.process(InputImage.fromBitmap(imagem, 0))
            .addOnSuccessListener { res ->
                ultimoTexto = res.text
                processar(Parser.extrair(res.text, termos), job)
            }
            .addOnFailureListener { processar(null, job) }
            .addOnCompleteListener {
                ocupado = false
                imagem.recycle()
            }
    }

    private fun processar(valor: Int?, job: Int) {
        val media = if (valor != null) Stats.media(Store.ler(this), Cfg.zeroEm(this), job) else Pair(null, 0)
        val aceito = guard.alimentar(valor, media.first, media.second)
        if (aceito != null) {
            val antes = Store.total(this)
            Store.adicionar(this, Entrada(System.currentTimeMillis(), job, aceito, sessao))
            val meta = Cfg.meta(this)
            if (meta > 0 && antes < meta && antes + aceito >= meta) avisarMeta()
            atualizarTexto()
            atualizarNotificacao()
        }
    }

    // ---------- calibração ----------

    private fun iniciarCalibracao() {
        if (calibrando) return
        calibrando = true
        painel.visibility = View.GONE
        raiz.visibility = View.INVISIBLE
        tentarCaptura(0)
    }

    private fun tentarCaptura(tentativa: Int) {
        handler.postDelayed({
            if (!rodando) return@postDelayed
            val foto = quadroAtual()
            if (foto != null) {
                mostrarCalibracao(foto)
            } else if (tentativa < 6) {
                tentarCaptura(tentativa + 1)
            } else {
                calibrando = false
                raiz.visibility = View.VISIBLE
                aviso("Não consegui capturar a tela. Tente de novo com o jogo aberto.")
            }
        }, if (tentativa == 0) 400L else 250L)
    }

    private fun mostrarCalibracao(foto: Bitmap) {
        val job = Cfg.job(this)
        fotoCalibracao = foto
        val view = CalibView(
            this, foto, Jobs.regiao(this, job),
            { regiao ->
                Jobs.salvarRegiao(this, job, regiao)
                fecharCalibracao()
                aviso("Região salva para " + Jobs.nomes[job])
            },
            { fecharCalibracao() }
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        calibView = view
        wm.addView(view, lp)
    }

    private fun fecharCalibracao() {
        val v = calibView
        if (v != null) {
            try {
                wm.removeView(v)
            } catch (_: Exception) {
            }
        }
        calibView = null
        fotoCalibracao?.recycle()
        fotoCalibracao = null
        calibrando = false
        guard.reset()
        if (::raiz.isInitialized) raiz.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        rodando = false
        sessaoInicio = 0L
        handler.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) {
            fecharCalibracao()
            try {
                wm.removeView(raiz)
            } catch (_: Exception) {
            }
        }
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        super.onDestroy()
    }
}
