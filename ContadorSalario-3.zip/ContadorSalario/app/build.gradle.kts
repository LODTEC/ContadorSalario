plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.exemplo.contador"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.contadorsalario"
        minSdk = 34
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }

    signingConfigs {
        create("fixa") {
            storeFile = file("assinatura.jks")
            storePassword = "contador123"
            keyAlias = "contador"
            keyPassword = "contador123"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("fixa")
            isMinifyEnabled = false
        }
        debug {
            signingConfig = signingConfigs.getByName("fixa")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
