package com.exemplo.contador

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var metaEt: EditText
    private lateinit var customBox: LinearLayout
    private val campos = mutableListOf<EditText>()
    private lateinit var termosEt: EditText

    private fun prefs() = getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun linha(pai: LinearLayout, rotulo: String, valor: String, numero: Boolean): EditText {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = rotulo; width = 300 })
        val et = EditText(this).apply {
            if (numero) inputType = InputType.TYPE_CLASS_NUMBER
            setText(valor)
        }
        row.addView(et, LinearLayout.LayoutParams(450, -2))
        pai.addView(row)
        return et
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = prefs()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply { text = "Contador de Salário"; textSize = 22f })
        root.addView(TextView(this).apply { text = "Trabalho:"; setPadding(0, 32, 0, 8) })

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Jobs.nomes)
        root.addView(spinner)

        customBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 0) }
        customBox.addView(TextView(this).apply { text = "Região da tela (em %) e texto do valor:" })
        val rotulos = listOf("Esquerda %", "Topo %", "Direita %", "Base %")
        val chaves = listOf("pl", "pt", "pr", "pb")
        val padroes = listOf(34, 84, 66, 96)
        for (i in 0..3) {
            campos.add(linha(customBox, rotulos[i], p.getInt(chaves[i], padroes[i]).toString(), true))
        }
        termosEt = linha(customBox, "Texto antes", p.getString("ptermos", "=").orEmpty(), false)
        root.addView(customBox)

        spinner.setSelection(Jobs.indice(this))
        customBox.visibility = if (Jobs.indice(this) == 3) View.VISIBLE else View.GONE
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                prefs().edit().putInt("job", pos).apply()
                customBox.visibility = if (pos == 3) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val metaRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 24, 0, 0) }
        metaRow.addView(TextView(this).apply { text = "Meta R$"; width = 300 })
        metaEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "0 = sem meta"
            setText(p.getLong("meta", 0).toString())
        }
        metaRow.addView(metaEt, LinearLayout.LayoutParams(450, -2))
        root.addView(metaRow)

        root.addView(Button(this).apply {
            text = "Salvar"
            setOnClickListener { salvar(); Toast.makeText(this@MainActivity, "Salvo", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply { text = "Iniciar"; setOnClickListener { iniciar() } })
        root.addView(Button(this).apply {
            text = "Parar"
            setOnClickListener { stopService(Intent(this@MainActivity, CounterService::class.java)) }
        })
        root.addView(Button(this).apply {
            text = "Zerar total"
            setOnClickListener {
                prefs().edit().putLong("total", 0).apply()
                Toast.makeText(this@MainActivity, "Zerado", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "No jogo: toque no balão para trocar de trabalho, segure 1 segundo para zerar, arraste para mover."
            setPadding(0, 32, 0, 0)
        })
        setContentView(root)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun salvar() {
        val e = prefs().edit()
        val chaves = listOf("pl", "pt", "pr", "pb")
        val padroes = listOf(34, 84, 66, 96)
        for (i in 0..3) {
            val v = campos[i].text.toString().toIntOrNull()?.coerceIn(0, 100) ?: padroes[i]
            e.putInt(chaves[i], v)
        }
        e.putString("ptermos", termosEt.text.toString().ifBlank { "=" })
        e.putLong("meta", metaEt.text.toString().toLongOrNull() ?: 0L)
        e.apply()
    }

    private fun iniciar() {
        salvar()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Permita a sobreposição e toque em Iniciar de novo", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CounterService::class.java)
                .putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Iniciado! Abra o jogo.", Toast.LENGTH_LONG).show()
        }
    }
}
