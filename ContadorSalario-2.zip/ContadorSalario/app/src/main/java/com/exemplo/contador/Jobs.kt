package com.exemplo.contador

import android.content.Context

object Jobs {
    val nomes = listOf("Caminhoneiro", "Entregador", "Fazenda", "Personalizado")

    data class Cfg(val l: Int, val t: Int, val r: Int, val b: Int, val termos: String)

    fun indice(ctx: Context): Int =
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("job", 0).coerceIn(0, nomes.size - 1)

    fun cfg(ctx: Context): Cfg {
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        return when (indice(ctx)) {
            0, 1 -> Cfg(34, 84, 66, 96, "=")
            2 -> Cfg(34, 84, 66, 96, "Total ganho:, ganho")
            else -> Cfg(
                p.getInt("pl", 34), p.getInt("pt", 84), p.getInt("pr", 66), p.getInt("pb", 96),
                p.getString("ptermos", "=").orEmpty()
            )
        }
    }
}
