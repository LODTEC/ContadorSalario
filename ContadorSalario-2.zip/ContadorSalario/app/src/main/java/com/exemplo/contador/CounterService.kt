package com.exemplo.contador

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CounterService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var curW = 0
    private var curH = 0
    private var dpi = 320

    private lateinit var wm: WindowManager
    private lateinit var overlay: TextView
    private lateinit var params: WindowManager.LayoutParams

    private var total = 0L
    private var ultimo = 0
    private var candidato = 0
    private var candContagem = 0
    private var faltas = 0
    private var busy = false
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            capturar()
            atualizarTexto()
            handler.postDelayed(this, 700)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "Contador", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, "c")
            .setContentTitle("Contador de salário ativo")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra("data", Intent::class.java) ?: return START_NOT_STICKY
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        total = getSharedPreferences("cfg", Context.MODE_PRIVATE).getLong("total", 0)
        criarOverlay()
        running = true
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun criarOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.GREEN)
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            setPadding(16, 6, 16, 6)
        }
        atualizarTexto()
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 200 }

        var sx = 0f; var sy = 0f; var px = 0; var py = 0; var t0 = 0L; var moved = false
        overlay.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; px = params.x; py = params.y
                    t0 = System.currentTimeMillis(); moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    params.x = px + dx; params.y = py + dy
                    wm.updateViewLayout(overlay, params)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (System.currentTimeMillis() - t0 > 1000) {
                            total = 0; salvar(); atualizarTexto()
                        } else {
                            trocarTrabalho()
                        }
                    }
                }
            }
            true
        }
        wm.addView(overlay, params)
    }

    private fun trocarTrabalho() {
        val novo = (Jobs.indice(this) + 1) % Jobs.nomes.size
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putInt("job", novo).apply()
        ultimo = 0; candidato = 0; candContagem = 0; faltas = 0
        atualizarTexto()
    }

    private fun atualizarTexto() {
        val meta = getSharedPreferences("cfg", Context.MODE_PRIVATE).getLong("meta", 0)
        val nome = Jobs.nomes[Jobs.indice(this)]
        if (meta <= 0) {
            overlay.text = "$nome\nR$ $total"
            overlay.setTextColor(Color.GREEN)
        } else if (total >= meta) {
            overlay.text = "$nome - META BATIDA!\nR$ $total / $meta"
            overlay.setTextColor(Color.YELLOW)
        } else {
            val pct = (total * 100 / meta).toInt()
            overlay.text = "$nome\nR$ $total / $meta\n$pct% - faltam ${meta - total}"
            overlay.setTextColor(Color.GREEN)
        }
    }

    private fun salvar() {
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putLong("total", total).apply()
    }

    private fun garantirDisplay() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        if (dm.widthPixels == curW && dm.heightPixels == curH && vDisplay != null) return
        curW = dm.widthPixels; curH = dm.heightPixels; dpi = dm.densityDpi
        val newReader = ImageReader.newInstance(curW, curH, PixelFormat.RGBA_8888, 2)
        if (vDisplay == null) {
            vDisplay = projection?.createVirtualDisplay(
                "cap", curW, curH, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, newReader.surface, null, null
            )
        } else {
            vDisplay?.resize(curW, curH, dpi)
            vDisplay?.surface = newReader.surface
        }
        reader?.close()
        reader = newReader
    }

    private fun capturar() {
        if (busy) return
        garantirDisplay()
        val img = reader?.acquireLatestImage() ?: return
        try {
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)

            val c = Jobs.cfg(this)
            val l = c.l / 100f; val t = c.t / 100f
            val r = c.r / 100f; val b = c.b / 100f
            val x = (img.width * l).toInt(); val y = (img.height * t).toInt()
            val w = ((img.width * (r - l)).toInt()).coerceAtLeast(10)
            val h = ((img.height * (b - t)).toInt()).coerceAtLeast(10)
            val crop = Bitmap.createBitmap(full, x, y, w, h)
            full.recycle()
            val big = Bitmap.createScaledBitmap(crop, w * 2, h * 2, true)
            crop.recycle()

            val termos = c.termos
            busy = true
            recognizer.process(InputImage.fromBitmap(big, 0))
                .addOnSuccessListener { res -> processar(extrair(res.text, termos)) }
                .addOnFailureListener { processar(null) }
                .addOnCompleteListener { busy = false; big.recycle() }
        } finally {
            img.close()
        }
    }

    private fun extrair(texto: String, termos: String): Int? {
        val lista = termos.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        for (t in lista) {
            val r = Regex(
                Regex.escape(t) + "\\s*:?\\s*(?:R\\$|RS|R5)?\\s*(\\d{1,6})",
                RegexOption.IGNORE_CASE
            )
            val v = r.find(texto)?.groupValues?.get(1)?.toIntOrNull()
            if (v != null) return v
        }
        return null
    }

    private fun processar(valor: Int?) {
        if (valor == null || valor <= 0) {
            faltas++
            if (faltas >= 2) { ultimo = 0; candidato = 0; candContagem = 0 }
            return
        }
        faltas = 0
        if (valor == candidato) candContagem++ else { candidato = valor; candContagem = 1 }
        if (candContagem >= 2 && valor != ultimo) {
            total += valor
            ultimo = valor
            salvar(); atualizarTexto()
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { wm.removeView(overlay) } catch (_: Exception) {}
        vDisplay?.release(); reader?.close(); projection?.stop()
        recognizer.close()
        super.onDestroy()
    }
}
