package com.exemplo.contador

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val fields = mutableListOf<EditText>()
    private lateinit var metaEt: EditText
    private val labels = listOf("Esquerda %", "Topo %", "Direita %", "Base %")
    private val defaults = listOf(42, 83, 58, 95)
    private val keys = listOf("l", "t", "r", "b")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Contador de Salário"; textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "Região da tela onde aparece o salário (em % da tela):"
            setPadding(0, 32, 0, 16)
        })
        for (i in 0..3) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = labels[i]; width = 300 })
            val et = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(prefs.getInt(keys[i], defaults[i]).toString())
            }
            fields.add(et); row.addView(et, LinearLayout.LayoutParams(300, -2))
            root.addView(row)
        }
        val metaRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 24, 0, 0) }
        metaRow.addView(TextView(this).apply { text = "Meta R$"; width = 300 })
        metaEt = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "0 = sem meta"
            setText(prefs.getLong("meta", 0).toString())
        }
        metaRow.addView(metaEt, LinearLayout.LayoutParams(400, -2))
        root.addView(metaRow)
        root.addView(Button(this).apply {
            text = "Salvar meta"
            setOnClickListener { salvarMeta(); Toast.makeText(this@MainActivity, "Meta salva", Toast.LENGTH_SHORT).show() }
        })
        root.addView(Button(this).apply {
            text = "Iniciar"; setOnClickListener { iniciar() }
        })
        root.addView(Button(this).apply {
            text = "Parar"; setOnClickListener { stopService(Intent(this@MainActivity, CounterService::class.java)) }
        })
        root.addView(Button(this).apply {
            text = "Zerar total"
            setOnClickListener {
                getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putLong("total", 0).apply()
                Toast.makeText(this@MainActivity, "Zerado", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Dica: segure o contador flutuante por 1 segundo para zerar. Arraste para mover."
            setPadding(0, 32, 0, 0)
        })
        setContentView(root)
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun salvarMeta() {
        val m = metaEt.text.toString().toLongOrNull() ?: 0L
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putLong("meta", m).apply()
    }

    private fun iniciar() {
        salvarMeta()
        val e = getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
        for (i in 0..3) {
            val v = fields[i].text.toString().toIntOrNull()?.coerceIn(0, 100) ?: defaults[i]
            e.putInt(keys[i], v)
        }
        e.apply()
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Permita a sobreposição e toque em Iniciar de novo", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CounterService::class.java)
                .putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Iniciado! Abra o jogo.", Toast.LENGTH_LONG).show()
        }
    }
}
